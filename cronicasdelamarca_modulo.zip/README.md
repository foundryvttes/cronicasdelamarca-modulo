# Módulo con distintos compendios para Crónicas de la Marca
![Portada de Crónicas de la Marca](https://i.imgur.com/RLvz0gC.png)

En este módulo podréis encontrar distintas colecciones que os facilitaran el crear y jugar partidas en Foundry para Crónicas de la Marca.

## ¿Qué es Crónicas de la Marca?
Crónicas de la Marca del Este es un juego de rol donde cada participante toma el papel de un intrépido aventurero, como si se tratase de una película donde los jugadores fueran los protagonistas, pudiendo alterar el curso de los acontecimientos a placer, y tan solo limitados por su imaginación. Durante el juego, vuestros aventureros lucharán contra monstruos, descubrirán ciudades perdidas, resolverán misterios y explorarán lugares remotos repletos de fortalezas, mazmorras y tesoros de incalculable valor. Con el tiempo, la fama y reputación de vuestros héroes crecerá a la par que sus riquezas, ganando niveles de juego según acumulen experiencia.
Podéis descargar su versión en PDF de manera totalmente gratuita desde: [Crónicas de la Marca](https://codexdelamarca.com/posts/downloads/Cronicasdelamarca.pdf)

## ¿Cómo puedo participar?

## Naturaleza del proyecto
